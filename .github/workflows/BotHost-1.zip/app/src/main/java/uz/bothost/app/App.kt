package uz.bothost.app

import android.Manifest
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

val BG = Color(0xFF070B10); val CARD = Color(0xFF111923)
val BLUE = Color(0xFF2979FF); val GREEN = Color(0xFF00E676); val RED = Color(0xFFFF1744)
val TXT = Color(0xFFE8EEF5); val SUB = Color(0xFF8A99AB)

@Composable fun BotTheme(c: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = BLUE, secondary = GREEN, error = RED, background = BG,
        surface = CARD, onBackground = TXT, onSurface = TXT), content = c)

fun fmt(ms: Long): String { val s = maxOf(0, ms) / 1000; return "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) }
fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

@Composable fun AnimBg(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxSize().background(BG).drawBehind {
        val w = size.width; val h = size.height
        drawRect(Brush.radialGradient(listOf(BLUE.copy(.30f), Color.Transparent), Offset(w * (.1f + .6f * a), h * .12f), w * .9f))
        drawRect(Brush.radialGradient(listOf(GREEN.copy(.18f), Color.Transparent), Offset(w * (.9f - .6f * a), h * .55f), w * .8f))
        drawRect(Brush.radialGradient(listOf(RED.copy(.14f), Color.Transparent), Offset(w * (.2f + .5f * a), h * .95f), w * .8f))
    }, content = content)
}

@Composable fun Pulse(color: Color, size: Dp) {
    val t = rememberInfiniteTransition(label = "p")
    val s by t.animateFloat(1f, 1.7f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "s")
    val al by t.animateFloat(.55f, 0f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "al")
    Box(Modifier.size(size * 1.7f), contentAlignment = Alignment.Center) {
        Box(Modifier.size(size * s).background(color.copy(al), CircleShape))
        Box(Modifier.size(size).background(color, CircleShape))
    }
}

@Composable fun GCard(mod: Modifier = Modifier, c: @Composable ColumnScope.() -> Unit) = Column(
    mod.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD.copy(alpha = .92f))
        .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp)).padding(16.dp).animateContentSize(),
    verticalArrangement = Arrangement.spacedBy(8.dp), content = c)

@Composable fun Btn(text: String, color: Color, mod: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) = Button(
    onClick, mod, enabled, shape = RoundedCornerShape(12.dp),
    colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = if (color == GREEN) Color.Black else Color.White),
    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)) { Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1) }

@Composable fun Title(t: String) = Text(t, fontSize = 22.sp, fontWeight = FontWeight.Black, color = TXT)
@Composable fun Sub(t: String) = Text(t, fontSize = 13.sp, color = SUB)
@Composable fun Chip(t: String, c: Color) = Text(t, color = c, fontWeight = FontWeight.Bold, fontSize = 12.sp,
    modifier = Modifier.border(1.dp, c, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 3.dp))

// ===================== ROOT =====================
@Composable fun BotHostRoot() {
    var user by remember { mutableStateOf(Store.user) }
    val scope = rememberCoroutineScope()
    AnimBg {
        Crossfade(user != null, label = "root", animationSpec = tween(500)) { logged ->
            if (logged) MainScreen {
                val names = Store.running().keys.toList()
                Store.clearAll(); Store.logout(); user = null
                scope.launch(Dispatchers.IO) { names.forEach { Py.stop(it) } }
            } else AuthScreen { user = Store.user }
        }
    }
}

// ===================== AUTH =====================
@Composable fun AuthScreen(onDone: () -> Unit) {
    var reg by remember { mutableStateOf(false) }
    var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Pulse(GREEN, 38.dp)
        Text("BotHost", fontSize = 36.sp, fontWeight = FontWeight.Black, color = TXT)
        Sub("Telegram botlar uchun hosting"); Spacer(Modifier.height(20.dp))
        GCard {
            Row {
                TextButton({ reg = false; err = null }, Modifier.weight(1f)) { Text("Kirish", color = if (!reg) GREEN else SUB, fontWeight = FontWeight.Bold) }
                TextButton({ reg = true; err = null }, Modifier.weight(1f)) { Text("Ro'yxatdan o'tish", color = if (reg) GREEN else SUB, fontWeight = FontWeight.Bold) }
            }
            OutlinedTextField(u, { u = it }, label = { Text("Nik") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(p, { p = it }, label = { Text("Parol") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            AnimatedVisibility(err != null) { Text(err ?: "", color = RED, fontSize = 13.sp) }
            Btn(if (reg) "Ro'yxatdan o'tish" else "Kirish", BLUE, Modifier.fillMaxWidth()) {
                err = if (reg) Store.register(u, p) else Store.login(u, p)
                if (err == null) onDone()
            }
        }
        Spacer(Modifier.height(8.dp)); Sub("Yangi akkaunt FREE tarifdan boshlanadi")
    }
}

// ===================== MAIN =====================
@Composable fun MainScreen(onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = buildList<Pair<String, ImageVector>> {
        add("Bosh" to Icons.Default.Home); add("Botlar" to Icons.Default.PlayArrow); add("Faol" to Icons.Default.Menu)
        add("Kutubxona" to Icons.Default.Build); add("Xarid" to Icons.Default.Star)
        if (Store.isAdmin) add("Admin" to Icons.Default.Lock)
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Store.running().isNotEmpty()) androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, BotService::class.java))
    }
    Scaffold(containerColor = Color.Transparent, bottomBar = {
        NavigationBar(containerColor = Color(0xE60B1119)) {
            tabs.forEachIndexed { i, (n, ic) ->
                NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) }, label = { Text(n, fontSize = 10.sp, maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = GREEN, selectedTextColor = GREEN,
                        indicatorColor = Color(0x3300E676), unselectedIconColor = SUB, unselectedTextColor = SUB))
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(tabs[tab.coerceAtMost(tabs.lastIndex)].first, label = "tab",
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }) { t ->
                when (t) {
                    "Bosh" -> HomeScreen(now, onLogout)
                    "Botlar" -> BotsScreen(now)
                    "Faol" -> ActiveScreen(now)
                    "Kutubxona" -> LibScreen()
                    "Xarid" -> ShopScreen(now)
                    else -> AdminScreen()
                }
            }
        }
    }
}

// ===================== HOME =====================
@Composable fun HomeScreen(now: Long, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val run = Store.running()
    val pm = ctx.getSystemService(PowerManager::class.java)
    val ignoring = pm.isIgnoringBatteryOptimizations(ctx.packageName)
    val df = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Title("Salom, ${Store.display}!"); Sub("BotHost boshqaruv paneli") }
            Chip(Store.planName, if (Store.isPro) GREEN else BLUE)
        }
        GCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Pulse(if (run.isNotEmpty()) GREEN else RED, 16.dp)
                Column {
                    Text("${run.size} / ${Store.maxBots()} bot faol", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TXT)
                    Sub(if (run.isNotEmpty()) "Server 24/7 ishlayapti" else "Hozircha bot ishlamayapti")
                }
            }
        }
        GCard {
            Text("Tarif: ${Store.planName}", fontWeight = FontWeight.Bold, color = if (Store.isPro) GREEN else BLUE)
            Sub("Bir vaqtda: ${Store.maxBots()} ta bot • Bot muddati: ${if (Store.isPro) "24" else "2"} soat")
            if (Store.isAdmin) Sub("Admin akkaunt — cheklovsiz PRO")
            else if (Store.isPro) Sub("PRO tugaydi: ${df.format(Date(Store.proUntil(Store.user!!)))}")
            else Sub("PRO uchun «Xarid» bo'limiga o'ting")
        }
        GCard {
            Text("Fon rejimi", fontWeight = FontWeight.Bold, color = TXT)
            Sub(if (ignoring) "✔ Batareya cheklovi o'chirilgan — bot 24/7 ishlaydi" else "Telefon uxlaganda bot to'xtamasligi uchun ruxsat bering")
            if (!ignoring) Btn("Ruxsat berish", GREEN, Modifier.fillMaxWidth()) {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
            }
        }
        Btn("Akkauntdan chiqish", RED, Modifier.fillMaxWidth(), onClick = onLogout)
        Sub("Eslatma: ilovani «oxirgi ilovalar»dan surib tashlasangiz, botlar to'xtaydi.")
    }
}

// ===================== BOTS (RUN) =====================
@Composable fun BotsScreen(now: Long) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    val files = remember(rev) { Store.botFiles(ctx) }
    val run = Store.running()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { runCatching { Store.importFile(ctx, it) } }; rev++
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Title("Bot fayllari"); Sub("«+» bilan .py fayl qo'shing. Bittasini ishga tushirib, boshqasini ham ishga tushiravering.") }
            if (files.isEmpty()) item { GCard { Text("Hali fayl yo'q. Pastdagi + tugmasini bosing.", color = SUB) } }
            items(files, key = { it }) { f ->
                val on = run.containsKey(f)
                GCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (on) Pulse(GREEN, 8.dp) else Box(Modifier.size(14.dp).background(SUB, CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) { Text(f, fontWeight = FontWeight.Bold, color = TXT, maxLines = 1); Sub(if (on) "Ishlayapti" else "To'xtagan") }
                        Btn(if (on) "Faol" else "▶ Run", GREEN, enabled = !on) {
                            scope.launch(Dispatchers.IO) { val e = BotManager.start(ctx, f); withContext(Dispatchers.Main) { e?.let { toast(ctx, it) } } }
                        }
                        IconButton({ scope.launch(Dispatchers.IO) { BotManager.delete(ctx, f); withContext(Dispatchers.Main) { rev++ } } }) {
                            Icon(Icons.Default.Delete, "o'chirish", tint = RED)
                        }
                    }
                }
            }
        }
        FloatingActionButton({ pick.launch(arrayOf("*/*")) }, Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = BLUE, contentColor = Color.White) { Icon(Icons.Default.Add, "qo'shish") }
    }
}

// ===================== ACTIVE =====================
@Composable fun LogBox(name: String) {
    val ctx = LocalContext.current
    var t by remember { mutableStateOf("") }
    LaunchedEffect(name) { while (true) { t = withContext(Dispatchers.IO) { Store.readLog(ctx, name) }; delay(2000) } }
    Box(Modifier.fillMaxWidth().height(220.dp).padding(top = 6.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black)
        .padding(8.dp).verticalScroll(rememberScrollState(), reverseScrolling = true)) {
        Text(t, color = GREEN, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}

@Composable fun ActiveScreen(now: Long) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val run = Store.running(); val life = Store.lifeMs()
    var logOf by remember { mutableStateOf<String?>(null) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("Ishlayotgan botlar (${run.size}/${Store.maxBots()})") }
        if (run.isEmpty()) item { GCard { Text("Faol bot yo'q. «Botlar» bo'limidan Run qiling.", color = SUB) } }
        items(run.entries.toList(), key = { it.key }) { e ->
            val left = life - (now - e.value)
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pulse(GREEN, 8.dp); Spacer(Modifier.width(8.dp))
                    Text(e.key, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = TXT, maxLines = 1)
                    Text(fmt(left), color = if (left < 600_000) RED else GREEN, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Btn("To'xtat", RED, Modifier.weight(1f)) { scope.launch(Dispatchers.IO) { BotManager.stop(e.key) } }
                    Btn("Qayta", BLUE, Modifier.weight(1f)) {
                        scope.launch(Dispatchers.IO) { val er = BotManager.restart(ctx, e.key); withContext(Dispatchers.Main) { er?.let { toast(ctx, it) } } }
                    }
                    Btn("Log", Color(0xFF334155), Modifier.weight(1f)) { logOf = if (logOf == e.key) null else e.key }
                    IconButton({ scope.launch(Dispatchers.IO) { BotManager.delete(ctx, e.key) } }) { Icon(Icons.Default.Delete, "o'chirish", tint = RED) }
                }
                AnimatedVisibility(logOf == e.key) { LogBox(e.key) }
            }
        }
    }
}

// ===================== LIBRARY =====================
@Composable fun LibScreen() {
    val scope = rememberCoroutineScope()
    var pkg by remember { mutableStateOf("") }; var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }; var list by remember { mutableStateOf(listOf<String>()) }
    fun refresh() { scope.launch(Dispatchers.IO) { val l = runCatching { Py.installed() }.getOrDefault(emptyList()); withContext(Dispatchers.Main) { list = l } } }
    fun doInstall(p: String) {
        if (p.isBlank() || busy) return
        busy = true; out = "Yuklanmoqda…"
        scope.launch(Dispatchers.IO) {
            val r = try { Py.install(p) } catch (e: Exception) { "Xato: ${e.message}" }
            withContext(Dispatchers.Main) { out = r; busy = false }; refresh()
        }
    }
    LaunchedEffect(Unit) { refresh() }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Title("Kutubxonalar"); Sub("Tayyor: python-telegram-bot, pyTelegramBotAPI (telebot), requests")
            Spacer(Modifier.height(8.dp))
            GCard {
                OutlinedTextField(pkg, { pkg = it }, label = { Text("Paket nomi (masalan: python-dotenv)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Btn(if (busy) "Kuting…" else "O'rnatish", GREEN, Modifier.fillMaxWidth(), enabled = !busy) { doInstall(pkg) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("python-dotenv", "beautifulsoup4", "pytz").forEach { n ->
                        AssistChip({ doInstall(n) }, { Text(n, fontSize = 11.sp) })
                    }
                }
                if (out.isNotEmpty()) Text(out, color = GREEN, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                Sub("Faqat sof-Python paketlar o'rnatiladi (numpy, pydantic-core kabi native paketlar yo'q).")
            }
        }
        item { Text("O'rnatilgan (qo'shimcha)", color = SUB, fontWeight = FontWeight.Bold) }
        if (list.isEmpty()) item { Sub("Hali qo'shimcha paket yo'q") }
        items(list, key = { it }) { n ->
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f), color = TXT, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    IconButton({ scope.launch(Dispatchers.IO) { val r = Py.uninstall(n); withContext(Dispatchers.Main) { out = r }; refresh() } }) {
                        Icon(Icons.Default.Delete, "o'chirish", tint = RED)
                    }
                }
            }
        }
    }
}

// ===================== SHOP =====================
@Composable fun ShopScreen(now: Long) {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("Xaridlar"); Sub("Joriy tarif: ${Store.planName}")
        GCard {
            Text("FREE", fontWeight = FontWeight.Black, color = BLUE, fontSize = 18.sp)
            Text("• 2 ta bot\n• Har 2 soatda botlar to'xtaydi (qayta Run qilinadi)", color = TXT)
        }
        GCard {
            Text("PRO", fontWeight = FontWeight.Black, color = GREEN, fontSize = 18.sp)
            Text("• 5 ta bot\n• 24 soatdan keyin to'xtaydi", color = TXT)
            Btn("Telegram: @suvorow1 orqali xarid", GREEN, Modifier.fillMaxWidth()) {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/suvorow1")))
            }
            Sub("To'lovdan so'ng admin sizga Pro-kod beradi. Kodni pastga kiriting.")
        }
        GCard {
            Text("Pro-kodni faollashtirish", fontWeight = FontWeight.Bold, color = TXT)
            OutlinedTextField(code, { code = it }, label = { Text("Kod") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Btn("Faollashtirish", BLUE, Modifier.fillMaxWidth()) {
                val e = Store.redeem(code); toast(ctx, e ?: "PRO faollashdi! 🎉"); if (e == null) code = ""
            }
        }
    }
}

// ===================== ADMIN =====================
@Composable fun AdminScreen() {
    val ctx = LocalContext.current
    var tu by remember { mutableStateOf("") }; var days by remember { mutableStateOf("30") }; var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("Admin panel"); Sub("Faqat admin uchun • bu qurilmada ${Store.userCount} foydalanuvchi")
        GCard {
            Text("PRO berish", fontWeight = FontWeight.Bold, color = GREEN)
            OutlinedTextField(tu, { tu = it }, label = { Text("Foydalanuvchi niki") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(days, { days = it.filter(Char::isDigit) }, label = { Text("Kun soni") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Btn("Pro-kod yaratish", BLUE, Modifier.fillMaxWidth()) {
                val d = days.toIntOrNull()
                if (tu.isBlank() || d == null || d <= 0) toast(ctx, "Nik va kunni to'g'ri kiriting") else code = Store.makeCode(tu, d)
            }
            if (code.isNotEmpty()) {
                SelectionContainer { Text(code, color = GREEN, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                Btn("Nusxalash", GREEN, Modifier.fillMaxWidth()) {
                    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", code)); toast(ctx, "Nusxalandi")
                }
                Sub("Kodni Telegramda foydalanuvchiga yuboring. U faqat shu nik uchun ishlaydi, bir marta.")
            }
            Btn("Shu qurilmadagi akkauntga darhol berish", Color(0xFF334155), Modifier.fillMaxWidth()) {
                val d = days.toIntOrNull()
                if (d == null || d <= 0) toast(ctx, "Kunni kiriting") else toast(ctx, Store.grantLocal(tu, d) ?: "PRO berildi")
            }
        }
    }
}
