package uz.bothost.app

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.io.File

object BotManager {
    /** IO oqimida chaqiring. Xato bo'lsa matn qaytaradi. */
    fun start(ctx: Context, name: String): String? {
        val run = Store.running()
        if (run.containsKey(name)) return "Allaqachon ishlayapti"
        if (run.size >= Store.maxBots()) return "Limit: ${Store.maxBots()} ta bot (${Store.planName}). PRO oling!"
        val f = File(Store.botsDir(ctx), name)
        if (!f.exists()) return "Fayl topilmadi"
        Store.setRun(name, System.currentTimeMillis())
        Py.start(name, f.absolutePath)
        ContextCompat.startForegroundService(ctx, Intent(ctx, BotService::class.java))
        return null
    }
    fun stop(name: String) { Py.stop(name); Store.clearRun(name) }
    fun restart(ctx: Context, name: String): String? { stop(name); return start(ctx, name) }
    fun delete(ctx: Context, name: String) { stop(name); File(Store.botsDir(ctx), name).delete() }
    fun stopAll() {
        val names = Store.running().keys.toList()
        Store.clearAll()
        names.forEach { Py.stop(it) }
    }
}
