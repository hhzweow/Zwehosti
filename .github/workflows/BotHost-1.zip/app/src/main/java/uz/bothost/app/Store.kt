package uz.bothost.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Store {
    private lateinit var sp: SharedPreferences
    private const val ADMIN = "zwe"
    private const val ADMIN_HASH = "2e88665fbb72a2b34bc4e849f1cacf2cfa9e891ec444c5e29ebfad732786b25f"
    private const val SECRET = "6b3024db3fda8c1b698537c685b55e98"
    const val H = 3600_000L

    fun init(c: Context) { sp = c.getSharedPreferences("bothost", Context.MODE_PRIVATE) }

    private fun sha(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(("BH|" + s).toByteArray()).joinToString("") { "%02x".format(it) }
    private fun mac(s: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        return m.doFinal(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
    }
    private fun users() = JSONObject(sp.getString("users", "{}")!!)

    // ---------- akkaunt ----------
    val user: String? get() = sp.getString("user", null)
    val isAdmin: Boolean get() = user == ADMIN
    val display: String get() = if (isAdmin) "Zwe" else (user ?: "")
    val userCount: Int get() = users().length()

    fun register(u0: String, p: String): String? {
        val u = u0.trim().lowercase()
        if (u.length < 3) return "Nik kamida 3 belgi bo'lsin"
        if (p.length < 4) return "Parol kamida 4 belgi bo'lsin"
        val us = users()
        if (u == ADMIN || us.has(u)) return "Bu nik band"
        us.put(u, sha(p))
        sp.edit().putString("users", us.toString()).putString("user", u).apply()
        return null
    }
    fun login(u0: String, p: String): String? {
        val u = u0.trim().lowercase()
        val us = users()
        val ok = if (u == ADMIN) sha(p) == ADMIN_HASH else us.has(u) && us.getString(u) == sha(p)
        if (!ok) return "Nik yoki parol xato"
        sp.edit().putString("user", u).apply()
        return null
    }
    fun logout() { sp.edit().remove("user").apply() }

    // ---------- tarif ----------
    fun proUntil(u: String) = sp.getLong("pro_$u", 0L)
    val isPro: Boolean get() = isAdmin || (user?.let { proUntil(it) > System.currentTimeMillis() } ?: false)
    val planName: String get() = if (isPro) "PRO" else "FREE"
    fun maxBots() = if (isPro) 5 else 2
    fun lifeMs() = if (isPro) 24 * H else 2 * H
    fun addPro(u: String, days: Int) {
        val k = u.lowercase()
        val base = maxOf(System.currentTimeMillis(), proUntil(k))
        sp.edit().putLong("pro_$k", base + days * 24 * H).apply()
    }
    fun grantLocal(u: String, days: Int): String? {
        if (!users().has(u.trim().lowercase())) return "Bu qurilmada bunday foydalanuvchi yo'q (kod yarating)"
        addPro(u.trim(), days); return null
    }

    // Pro kod: admin yaratadi, foydalanuvchi o'z qurilmasida kiritadi (internet/server kerak emas)
    fun makeCode(u: String, days: Int): String {
        val payload = "${u.trim().lowercase()}|$days|${System.nanoTime().toString(36)}"
        return Base64.encodeToString(payload.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING) + "." + mac(payload)
    }
    fun redeem(code: String): String? {
        val u = user ?: return "Akkauntga kiring"
        val parts = code.trim().split(".")
        if (parts.size != 2) return "Kod noto'g'ri"
        val payload = try { String(Base64.decode(parts[0], Base64.URL_SAFE)) } catch (e: Exception) { return "Kod noto'g'ri" }
        if (mac(payload) != parts[1]) return "Kod soxta yoki xato"
        val f = payload.split("|")
        if (f.size != 3 || f[0] != u) return "Bu kod boshqa akkaunt uchun"
        val used = sp.getStringSet("used", emptySet())!!
        if (used.contains(parts[1])) return "Bu kod ishlatilgan"
        addPro(u, f[1].toIntOrNull() ?: return "Kod noto'g'ri")
        sp.edit().putStringSet("used", used + parts[1]).apply()
        return null
    }

    // ---------- ishlayotgan botlar ----------
    fun running(): Map<String, Long> {
        val o = JSONObject(sp.getString("run", "{}")!!)
        return o.keys().asSequence().associateWith { o.getLong(it) }
    }
    @Synchronized fun setRun(n: String, t: Long) {
        val o = JSONObject(sp.getString("run", "{}")!!); o.put(n, t); sp.edit().putString("run", o.toString()).apply()
    }
    @Synchronized fun clearRun(n: String) {
        val o = JSONObject(sp.getString("run", "{}")!!); o.remove(n); sp.edit().putString("run", o.toString()).apply()
    }
    @Synchronized fun clearAll() { sp.edit().putString("run", "{}").apply() }

    // ---------- fayllar ----------
    fun botsDir(c: Context) = File(c.filesDir, "bots").apply { mkdirs() }
    fun botFiles(c: Context): List<String> =
        botsDir(c).listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList()
    fun importFile(c: Context, uri: Uri) {
        var name: String? = null
        c.contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) }
        }
        val n = (name ?: "bot_${System.currentTimeMillis()}.py").replace("/", "_")
        c.contentResolver.openInputStream(uri)?.use { inp -> File(botsDir(c), n).outputStream().use { inp.copyTo(it) } }
    }
    fun readLog(c: Context, n: String): String {
        val f = File(c.filesDir, "logs/$n.log")
        return if (f.exists()) f.readText().takeLast(6000).ifBlank { "Log bo'sh" } else "Log bo'sh"
    }
}
