package uz.bothost.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import java.io.File

class BotService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var wl: PowerManager.WakeLock? = null
    private val ch = "bothost"

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("BotHost").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).setContentIntent(pi).build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(ch, "BotHost", NotificationManager.IMPORTANCE_LOW))
        val n = notif("Botlar ishlamoqda…")
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bothost:wl").apply { acquire() }
        }
        if (job == null) job = scope.launch { while (isActive) { try { tick(nm) } catch (_: Exception) {}; delay(15000) } }
        return START_STICKY
    }

    private fun tick(nm: NotificationManager) {
        if (Store.user == null) { stopSelf(); return }
        val life = Store.lifeMs(); val now = System.currentTimeMillis()
        for ((name, t) in Store.running()) {
            if (now - t >= life) { Py.stop(name); Store.clearRun(name); continue }   // muddat tugadi
            when (Py.status(name)) {
                0 -> { val f = File(Store.botsDir(this), name); if (f.exists()) Py.start(name, f.absolutePath) else Store.clearRun(name) }
                -1 -> Store.clearRun(name)   // bot o'zi tugagan/xato bilan to'xtagan (log saqlanadi)
            }
        }
        val n = Store.running().size
        if (n == 0) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        nm.notify(1, notif("$n ta bot faol • ${Store.planName}"))
    }

    override fun onDestroy() {
        job?.cancel(); wl?.let { if (it.isHeld) it.release() }; super.onDestroy()
    }
}
