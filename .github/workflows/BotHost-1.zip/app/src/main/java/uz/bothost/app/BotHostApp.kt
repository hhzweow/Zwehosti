package uz.bothost.app

import android.app.Application

class BotHostApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Py.init(this)
    }
}
