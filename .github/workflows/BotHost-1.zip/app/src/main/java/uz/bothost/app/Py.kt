package uz.bothost.app

import android.content.Context
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

object Py {
    private var mod: PyObject? = null
    fun init(c: Context) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(c))
        mod = Python.getInstance().getModule("runner")
        mod!!.callAttr("setup", c.filesDir.absolutePath)
    }
    fun start(name: String, path: String) = mod!!.callAttr("start", name, path).toBoolean()
    fun stop(name: String) { mod!!.callAttr("stop", name) }
    /** 1 = ishlayapti, 0 = noma'lum (jarayon qayta boshlangan), -1 = o'zi tugagan */
    fun status(name: String) = mod!!.callAttr("status", name).toInt()
    fun install(p: String) = mod!!.callAttr("install", p).toString()
    fun uninstall(p: String) = mod!!.callAttr("uninstall", p).toString()
    fun installed(): List<String> = mod!!.callAttr("installed").asList().map { it.toString() }
}
