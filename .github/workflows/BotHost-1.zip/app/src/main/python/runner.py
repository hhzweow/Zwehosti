import sys, os, re, io, json, time, signal, ctypes, runpy, asyncio, threading, traceback
import zipfile, importlib, importlib.metadata, urllib.request, shutil, tempfile

BASE = SITE = LOGS = None
BOTS = {}
_files = {}
_lock = threading.Lock()


class _Out:
    def __init__(self, orig):
        self.orig = orig
    def write(self, s):
        n = getattr(threading.current_thread(), "_bot", None)
        f = _files.get(n)
        if f:
            try:
                f.write(s); f.flush()
            except Exception:
                pass
        else:
            self.orig.write(s)
        return len(s)
    def flush(self):
        pass
    def isatty(self):
        return False
    def __getattr__(self, a):
        return getattr(self.orig, a)


def setup(base):
    global BASE, SITE, LOGS
    BASE = base
    SITE = os.path.join(base, "site")
    LOGS = os.path.join(base, "logs")
    os.makedirs(SITE, exist_ok=True)
    os.makedirs(LOGS, exist_ok=True)
    if SITE not in sys.path:
        sys.path.append(SITE)
    # thread -> bot name inheritance
    orig_init = threading.Thread.__init__
    def _init(self, *a, **k):
        orig_init(self, *a, **k)
        self._bot = getattr(threading.current_thread(), "_bot", None)
    threading.Thread.__init__ = _init
    # signals only work in main thread; bots run in worker threads
    sig = signal.signal
    def _safe(s, h):
        if threading.current_thread() is threading.main_thread():
            return sig(s, h)
        return None
    signal.signal = _safe
    import asyncio.unix_events as ue
    ue._UnixSelectorEventLoop.add_signal_handler = lambda self, *a, **k: None
    ue._UnixSelectorEventLoop.remove_signal_handler = lambda self, *a, **k: False
    sys.stdout = _Out(sys.stdout)
    sys.stderr = _Out(sys.stderr)


def _kill(t):
    if t.ident is not None:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(t.ident), ctypes.py_object(SystemExit))


def start(name, path):
    with _lock:
        b = BOTS.get(name)
        if b and b["t"].is_alive():
            return True
        lp = os.path.join(LOGS, name + ".log")
        mode = "w" if os.path.exists(lp) and os.path.getsize(lp) > 200000 else "a"
        _files[name] = open(lp, mode, buffering=1, encoding="utf-8", errors="replace")
        b = {"state": "running", "loop": None}
        def run():
            threading.current_thread()._bot = name
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            b["loop"] = loop
            d = os.path.dirname(path)
            if d not in sys.path:
                sys.path.insert(0, d)
            print("[host] %s ishga tushdi  %s" % (name, time.strftime("%H:%M:%S")))
            try:
                runpy.run_path(path, run_name="__main__")
            except SystemExit:
                pass
            except BaseException:
                if b["state"] != "stopping":
                    traceback.print_exc()
            finally:
                b["state"] = "ended"
                print("[host] %s tugadi" % name)
        t = threading.Thread(target=run, daemon=True, name="bot-" + name)
        b["t"] = t
        BOTS[name] = b
        t.start()
        return True


def stop(name):
    b = BOTS.get(name)
    if not b:
        return
    b["state"] = "stopping"
    loop = b.get("loop")
    if loop:
        try:
            loop.call_soon_threadsafe(loop.stop)
        except Exception:
            pass
    for t in list(threading.enumerate()):
        if getattr(t, "_bot", None) == name and t is not threading.current_thread():
            _kill(t)
    b["t"].join(3)
    BOTS.pop(name, None)
    f = _files.pop(name, None)
    if f:
        try:
            f.write("[host] to'xtatildi\n"); f.close()
        except Exception:
            pass


def status(name):
    b = BOTS.get(name)
    if not b:
        return 0
    return 1 if b["t"].is_alive() else -1


# ---------------- kutubxona (pip) ----------------
def _norm(n):
    return re.sub(r"[-_.]+", "-", n).lower()

def _dist_dirs():
    return [d for d in os.listdir(SITE) if d.endswith(".dist-info")]

def _have(name):
    for d in _dist_dirs():
        if _norm(d[:-10].rsplit("-", 1)[0]) == name:
            return True
    try:
        importlib.metadata.version(name)
        return True
    except Exception:
        return False

def _marker_ok(m):
    for bad in ("win32", "Windows", "darwin", "Darwin", "emscripten"):
        if bad in m:
            return False
    mm = re.fullmatch(r'\s*python_version\s*(<=|>=|<|>|==)\s*["\']([\d.]+)["\']\s*', m)
    if mm:
        cur = tuple(sys.version_info[:2])
        want = tuple(int(x) for x in mm.group(2).split("."))[:2]
        op = mm.group(1)
        return {"<": cur < want, "<=": cur <= want, ">": cur > want, ">=": cur >= want, "==": cur == want}[op]
    return True

def _inst(spec, out, seen):
    m = re.match(r"\s*([A-Za-z0-9_.\-]+)\s*(?:\[[^\]]*\])?\s*(.*)", spec)
    name = _norm(m.group(1))
    ver = re.match(r"==\s*([\w.]+)", m.group(2) or "")
    if name in seen:
        return
    seen.add(name)
    if _have(name):
        out.append("✓ %s mavjud" % name)
        return
    url = "https://pypi.org/pypi/%s%s/json" % (name, "/" + ver.group(1) if ver else "")
    data = json.load(urllib.request.urlopen(url, timeout=30))
    whl = [u for u in data["urls"] if u["filename"].endswith("-none-any.whl")]
    if not whl:
        raise Exception("%s: sof-Python wheel yo'q (native paket qo'llab-quvvatlanmaydi)" % name)
    out.append("↓ %s %s" % (name, data["info"]["version"]))
    tmp = tempfile.mktemp(suffix=".whl")
    with urllib.request.urlopen(whl[0]["url"], timeout=90) as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f)
    with zipfile.ZipFile(tmp) as z:
        z.extractall(SITE)
    os.remove(tmp)
    for r in data["info"].get("requires_dist") or []:
        req, _, marker = r.partition(";")
        if "extra" in marker or (marker and not _marker_ok(marker)):
            continue
        _inst(req.strip(), out, seen)

def install(pkg):
    out = []
    try:
        _inst(pkg.strip(), out, set())
        out.append("TAYYOR ✔")
    except Exception as e:
        out.append("XATO: %s" % e)
    importlib.invalidate_caches()
    return "\n".join(out)

def installed():
    res = []
    for d in sorted(_dist_dirs()):
        res.append(d[:-10].rsplit("-", 1)[0] + "==" + d[:-10].rsplit("-", 1)[1])
    return res

def uninstall(name):
    name = _norm(name.split("==")[0])
    for d in _dist_dirs():
        if _norm(d[:-10].rsplit("-", 1)[0]) == name:
            rec = os.path.join(SITE, d, "RECORD")
            if os.path.exists(rec):
                for line in open(rec, encoding="utf-8"):
                    p = os.path.normpath(os.path.join(SITE, line.split(",")[0]))
                    if p.startswith(SITE) and os.path.isfile(p):
                        os.remove(p)
            shutil.rmtree(os.path.join(SITE, d), ignore_errors=True)
            for root, dirs, files in os.walk(SITE, topdown=False):
                if root != SITE and not os.listdir(root):
                    os.rmdir(root)
            return "O'chirildi: " + name
    return "Topilmadi (o'rnatilgan paketlar ichida emas)"
