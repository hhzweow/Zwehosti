# BotHost
1. GitHub'da yangi repo oching, shu papkadagi hamma fayllarni (`.github` ham) yuklang.
2. Repo → Actions → "Build APK" → tugagach Artifacts → BotHost-apk.
3. Admin: Zwe (parol sizniki). Pro-kod: Admin → Pro berish.
